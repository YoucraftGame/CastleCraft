CastleCraft 完整版

先阅读 README.md 和 教程/安装教程.html。
安装包已编译，无需自己构建。安装前退出两个游戏并备份已有模组。
版本：repair-fallen-hunter-mapping-20261014
额外玩法模组按清单自行安装。
